"""
Yoga Pose Correction GUI launcher.
- Simple local demo login (not production authentication).
- Pose selection and session logging.
- Starts the existing synchronized webcam runner as a child process.
Keep this file beside v8.py and realtime_pose_predict_sync.py.
"""
from __future__ import annotations

import csv
import hashlib
import hmac
import json
import secrets
import os
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
RUNNER = BASE_DIR / "realtime_pose_predict_sync.py"
SESSION_LOG = BASE_DIR / "session_history.csv"
AUTH_FILE = BASE_DIR / "login_credentials.json"
PBKDF2_ITERATIONS = 310_000

POSES = [
    "Ardha Chandrasana",
    "Bhujangasana",
    "Tadasana",
    "Trikonasana",
    "Vrikshasana",
]


class YogaPoseGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Yoga Pose Correction System")
        self.root.geometry("780x570")
        self.root.minsize(720, 520)
        self.process: subprocess.Popen | None = None
        self.session_user = ""
        self.session_started = None

        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"))
        self.style.configure("Subtitle.TLabel", font=("Segoe UI", 10))
        self.style.configure("Section.TLabel", font=("Segoe UI", 13, "bold"))
        self.style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=8)

        self.container = ttk.Frame(root, padding=24)
        self.container.pack(fill="both", expand=True)
        self.show_login()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    @staticmethod
    def _password_record(password: str, salt: bytes | None = None) -> dict:
        salt = salt or secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS
        )
        return {
            "salt": salt.hex(),
            "password_hash": digest.hex(),
            "iterations": PBKDF2_ITERATIONS,
        }

    @staticmethod
    def _verify_password(password: str, record: dict) -> bool:
        try:
            salt = bytes.fromhex(record["salt"])
            iterations = int(record.get("iterations", PBKDF2_ITERATIONS))
            actual = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"), salt, iterations
            ).hex()
            return hmac.compare_digest(actual, record["password_hash"])
        except (KeyError, TypeError, ValueError):
            return False

    def _load_credentials(self):
        try:
            with open(AUTH_FILE, "r", encoding="utf-8") as f:
                record = json.load(f)
            if record.get("username") and record.get("salt") and record.get("password_hash"):
                return record
        except (OSError, json.JSONDecodeError):
            pass
        return None

    def _save_credentials(self, username: str, password: str):
        record = self._password_record(password)
        record["username"] = username
        temporary = AUTH_FILE.with_suffix(".tmp")
        with open(temporary, "w", encoding="utf-8") as f:
            json.dump(record, f, indent=2)
        os.replace(temporary, AUTH_FILE)

    def clear(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    def show_login(self):
        self.clear()
        self.session_user = ""
        credentials = self._load_credentials()
        card = ttk.Frame(self.container, padding=26)
        card.place(relx=0.5, rely=0.47, anchor="center", width=520)

        ttk.Label(card, text="Yoga Pose Correction", style="Title.TLabel").pack(pady=(0, 5))
        ttk.Label(card, text="Real-time posture analysis with visual and audio feedback",
                  style="Subtitle.TLabel", wraplength=440).pack(pady=(0, 22))

        if credentials is None:
            ttk.Label(card, text="Create your login", style="Section.TLabel").pack(anchor="w", pady=(0, 12))
            ttk.Label(card, text="Username").pack(anchor="w")
            self.setup_username_var = tk.StringVar()
            ttk.Entry(card, textvariable=self.setup_username_var, font=("Segoe UI", 11)).pack(
                fill="x", pady=(4, 10), ipady=4
            )
            ttk.Label(card, text="Choose password (at least 8 characters)").pack(anchor="w")
            self.setup_password_var = tk.StringVar()
            ttk.Entry(card, textvariable=self.setup_password_var, show="*", font=("Segoe UI", 11)).pack(
                fill="x", pady=(4, 10), ipady=4
            )
            ttk.Label(card, text="Confirm password").pack(anchor="w")
            self.setup_confirm_var = tk.StringVar()
            ttk.Entry(card, textvariable=self.setup_confirm_var, show="*", font=("Segoe UI", 11)).pack(
                fill="x", pady=(4, 16), ipady=4
            )
            ttk.Button(card, text="Save Login and Continue", style="Primary.TButton",
                       command=self.create_login).pack(fill="x")
            ttk.Label(
                card,
                text="Your password is stored locally as a salted hash, not as plain text.",
                style="Subtitle.TLabel", wraplength=440
            ).pack(anchor="w", pady=(12, 0))
        else:
            ttk.Label(card, text="Login", style="Section.TLabel").pack(anchor="w", pady=(0, 12))
            ttk.Label(card, text="Username").pack(anchor="w")
            self.username_var = tk.StringVar(value=credentials.get("username", ""))
            ttk.Entry(card, textvariable=self.username_var, font=("Segoe UI", 11)).pack(
                fill="x", pady=(4, 10), ipady=4
            )
            ttk.Label(card, text="Password").pack(anchor="w")
            self.password_var = tk.StringVar()
            password_entry = ttk.Entry(card, textvariable=self.password_var, show="*", font=("Segoe UI", 11))
            password_entry.pack(fill="x", pady=(4, 16), ipady=4)
            password_entry.bind("<Return>", lambda _event: self.login())
            ttk.Button(card, text="Login", style="Primary.TButton",
                       command=self.login).pack(fill="x")
            ttk.Label(card, text="Forgot your password? For this local demo, delete login_credentials.json to set it up again.",
                      style="Subtitle.TLabel", wraplength=440).pack(anchor="w", pady=(12, 0))

    def create_login(self):
        username = self.setup_username_var.get().strip()
        password = self.setup_password_var.get()
        confirm = self.setup_confirm_var.get()
        if not username:
            messagebox.showwarning("Username required", "Enter a username.")
            return
        if len(password) < 8:
            messagebox.showwarning("Password too short", "Use at least 8 characters.")
            return
        if password != confirm:
            messagebox.showwarning("Passwords do not match", "Enter the same password in both fields.")
            return
        try:
            self._save_credentials(username, password)
        except OSError as exc:
            messagebox.showerror("Could not save login", str(exc))
            return
        messagebox.showinfo("Login created", "Your login has been saved. You can now sign in.")
        self.show_login()

    def login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get()
        credentials = self._load_credentials()
        if credentials is None:
            self.show_login()
            return
        username_matches = hmac.compare_digest(
            username.casefold(), str(credentials.get("username", "")).casefold()
        )
        if not username_matches or not self._verify_password(password, credentials):
            messagebox.showerror("Login failed", "Incorrect username or password.")
            return
        self.session_user = credentials["username"]
        self.show_dashboard()

    def show_dashboard(self):
        self.clear()
        header = ttk.Frame(self.container)
        header.pack(fill="x", pady=(0, 18))
        ttk.Label(header, text="Yoga Pose Correction", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text=f"Logged in for this local session as: {self.session_user}",
                  style="Subtitle.TLabel").pack(anchor="w", pady=(4, 0))

        ttk.Separator(self.container).pack(fill="x", pady=(0, 18))
        ttk.Label(self.container, text="Choose a yoga pose", style="Section.TLabel").pack(anchor="w")
        self.pose_var = tk.StringVar(value=POSES[0])
        pose_box = ttk.Combobox(self.container, textvariable=self.pose_var, values=POSES,
                                state="readonly", font=("Segoe UI", 11))
        pose_box.pack(fill="x", pady=(8, 18), ipady=5)

        info = ttk.LabelFrame(self.container, text="What happens next?", padding=14)
        info.pack(fill="x", pady=(0, 18))
        for line in [
            "1. The selected trained model is loaded.",
            "2. The webcam analyzes the pose and checks safety rules.",
            "3. A confirmed Correct pose starts the stability hold timer.",
            "4. The runner shows correction messages and speaks synchronized feedback.",
            "Keyboard controls in the webcam window: D = debug overlay, Q = quit webcam.",
        ]:
            ttk.Label(info, text=line, wraplength=650).pack(anchor="w", pady=3)

        self.status_var = tk.StringVar(value="Ready to start.")
        ttk.Label(self.container, textvariable=self.status_var).pack(anchor="w", pady=(0, 10))

        buttons = ttk.Frame(self.container)
        buttons.pack(fill="x")
        self.start_button = ttk.Button(buttons, text="Start Webcam Session",
                                       style="Primary.TButton", command=self.start_session)
        self.start_button.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(buttons, text="View Session History", command=self.show_history).pack(side="left", padx=4)
        ttk.Button(buttons, text="Change Password", command=self.change_password).pack(side="left", padx=4)
        ttk.Button(buttons, text="Log out", command=self.show_login).pack(side="right", padx=(8, 0))

    def change_password(self):
        credentials = self._load_credentials()
        if credentials is None:
            messagebox.showerror("Login unavailable", "No saved login was found. Log out and create a new login.")
            return

        win = tk.Toplevel(self.root)
        win.title("Change Password")
        win.geometry("430x330")
        win.resizable(False, False)
        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)

        current_var = tk.StringVar()
        new_var = tk.StringVar()
        confirm_var = tk.StringVar()

        ttk.Label(frame, text="Change Password", style="Section.TLabel").pack(anchor="w", pady=(0, 12))
        for label, variable in [
            ("Current password", current_var),
            ("New password (at least 8 characters)", new_var),
            ("Confirm new password", confirm_var),
        ]:
            ttk.Label(frame, text=label).pack(anchor="w", pady=(5, 0))
            ttk.Entry(frame, textvariable=variable, show="*", font=("Segoe UI", 10)).pack(
                fill="x", pady=(3, 5), ipady=3
            )

        def save_new_password():
            current = current_var.get()
            new = new_var.get()
            confirm = confirm_var.get()
            latest = self._load_credentials()
            if latest is None or not self._verify_password(current, latest):
                messagebox.showerror("Incorrect password", "Your current password is incorrect.", parent=win)
                return
            if len(new) < 8:
                messagebox.showwarning("Password too short", "Use at least 8 characters.", parent=win)
                return
            if new != confirm:
                messagebox.showwarning("Passwords do not match", "Confirm the new password correctly.", parent=win)
                return
            if self._verify_password(new, latest):
                messagebox.showwarning("Choose a new password", "Your new password must differ from the current password.", parent=win)
                return
            try:
                self._save_credentials(latest["username"], new)
            except OSError as exc:
                messagebox.showerror("Could not save password", str(exc), parent=win)
                return
            messagebox.showinfo("Password changed", "Your password has been changed.", parent=win)
            win.destroy()

        ttk.Button(frame, text="Save New Password", style="Primary.TButton",
                   command=save_new_password).pack(fill="x", pady=(14, 0))

    def start_session(self):
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Session running", "A webcam session is already running.")
            return
        if not RUNNER.exists():
            messagebox.showerror("Missing runner", f"Could not find:\n{RUNNER}")
            return
        pose = self.pose_var.get()
        env = os.environ.copy()
        env["YOGA_SELECTED_POSE"] = pose
        try:
            log_path = BASE_DIR / "last_session_output.log"
            log_file = open(log_path, "a", encoding="utf-8")
            log_file.write(f"\n\n=== GUI session started {datetime.now().isoformat(timespec='seconds')} | user={self.session_user} | pose={pose} ===\n")
            log_file.flush()
            self.process = subprocess.Popen(
                [sys.executable, str(RUNNER)],
                cwd=str(BASE_DIR),
                env=env,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                creationflags=(subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0),
            )
            # Parent owns the log file for the child's lifetime; keep a reference.
            self._log_file = log_file
            self.session_started = datetime.now()
            self.write_session_row(self.session_user, pose, self.session_started, "")
            self.status_var.set(f"Running {pose}. Use Q in the webcam window to end the session.")
            self.start_button.configure(state="disabled")
            self.root.after(700, self.check_process)
        except Exception as exc:
            messagebox.showerror("Could not start webcam", str(exc))
            self.status_var.set("Could not start webcam.")

    def check_process(self):
        if not self.process:
            return
        code = self.process.poll()
        if code is None:
            self.root.after(700, self.check_process)
            return
        ended = datetime.now()
        if self.session_started:
            self.update_last_session_end(ended)
        if hasattr(self, "_log_file"):
            try:
                self._log_file.close()
            except Exception:
                pass
        self.start_button.configure(state="normal")
        self.status_var.set(f"Session ended (exit code {code}). Log: last_session_output.log")
        self.process = None
        self.session_started = None

    def write_session_row(self, user, pose, start, end):
        exists = SESSION_LOG.exists()
        with open(SESSION_LOG, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["username", "pose", "started_at", "ended_at"])
            if not exists:
                writer.writeheader()
            writer.writerow({"username": user, "pose": pose,
                             "started_at": start.isoformat(timespec="seconds"),
                             "ended_at": end})

    def update_last_session_end(self, ended):
        # Update the most recent session row (the GUI owns this local CSV).
        if not SESSION_LOG.exists():
            return
        with open(SESSION_LOG, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        if rows:
            rows[-1]["ended_at"] = ended.isoformat(timespec="seconds")
            with open(SESSION_LOG, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=["username", "pose", "started_at", "ended_at"])
                writer.writeheader()
                writer.writerows(rows)

    def show_history(self):
        win = tk.Toplevel(self.root)
        win.title("Session History")
        win.geometry("680x330")
        cols = ("username", "pose", "started_at", "ended_at")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        for col, title in zip(cols, ("User", "Pose", "Started", "Ended")):
            tree.heading(col, text=title)
            tree.column(col, width=155, anchor="w")
        tree.pack(fill="both", expand=True, padx=12, pady=12)
        if SESSION_LOG.exists():
            with open(SESSION_LOG, newline="", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    tree.insert("", "end", values=tuple(row.get(c, "") for c in cols))
        else:
            tree.insert("", "end", values=("No sessions recorded yet", "", "", ""))

    def on_close(self):
        if self.process and self.process.poll() is None:
            if not messagebox.askyesno("Exit", "A webcam session is running. Stop it and exit?"):
                return
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
        try:
            if hasattr(self, "_log_file"):
                self._log_file.close()
        except Exception:
            pass
        self.root.destroy()


def main():
    root = tk.Tk()
    YogaPoseGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
